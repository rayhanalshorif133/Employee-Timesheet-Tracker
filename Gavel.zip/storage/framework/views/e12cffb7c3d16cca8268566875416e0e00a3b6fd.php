


<?php $__env->startPush('styles'); ?>
    <style>
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">

        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Bids /</span> Bid List
        </h4>

        <div class="card my-3">
            <div class="card-body">
                <h5 class="mt-3">Bids List</h5>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5 class="text-bolder">Product Name: <span>
                            <?php if(count($bids) > 0): ?>
                                <?php echo e($bids[0]->product->name); ?>

                            <?php endif; ?>
                        </span></h5>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User Name/Phone</th>
                            <th>Bid Amount</th>
                            <th>Date & Time</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td>
                                    <a href="<?php echo e(route('user.edit', $bid->user->id)); ?>">
                                        <?php echo e($bid->user->name ? $bid->user->username : $bid->user->phone); ?>

                                    </a>
                                </td>
                                <td><?php echo e($bid->amount); ?></td>
                                <td>
                                    <?php
                                        $date_time = \Carbon\Carbon::parse($bid->date_time)->format('d-m-Y h:i A');
                                    ?>
                                    <?php echo e($date_time); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/bid/show.blade.php ENDPATH**/ ?>