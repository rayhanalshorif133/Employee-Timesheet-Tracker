


<?php $__env->startPush('styles'); ?>
    <style>
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        

        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Categories /</span> Category List
        </h4>

        <!-- Hoverable Table rows -->
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5>Categories List</h5>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#createNewCategory">Add New</button>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Count of Products</th>
                            <th>Status</th>
                            <th>Date Range</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td>
                                    <a href="<?php echo e($category->image); ?>" data-lightbox="<?php echo e($category->name); ?>"
                                        data-title="<?php echo e($category->name); ?>">
                                        <img src="<?php echo e($category->image); ?>" alt="<?php echo e($category->name); ?>"
                                            class="d-block rounded" height="50" width="50" />
                                    </a>
                                </td>
                                <td>
                                    <?php echo e($category->name); ?>

                                </td>
                                <td class="text-center mx-auto">
                                    <?php echo e($category->products->count()); ?>

                                </td>
                                <td>
                                    <?php if($category->status == 'running'): ?>
                                        <span class="badge bg-label-success me-1"><?php echo e($category->status); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-label-danger me-1"><?php echo e($category->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($category->start_date); ?>

                                    <span class="me-1">-</span>
                                    <?php echo e($category->end_date); ?>


                                </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example" data-url="<?php echo e(route('category.delete',$category->id)); ?>">
                                        <a class="btn btn-outline-success btn-sm categoryViewBtn" data-id="<?php echo e($category->id); ?>" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#viewCategory">
                                            <i class="bx bxs-show"></i>
                                        </a>
                                        <a class="btn btn-outline-info btn-sm categoryEditBtn" data-id="<?php echo e($category->id); ?>" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#updateCategory"><i
                                                class="bx bx-edit-alt"></i></a>
                                        <a class="btn btn-outline-danger btn-sm itemDeleteBtn"  href="javascript:void(0);">
                                            <i class="bx bx-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo $__env->make('category.view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('category.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/category/index.blade.php ENDPATH**/ ?>