<div class="modal fade" id="createNewScopeOfDelivery" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">
                    Create New Scope Of Delivery
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="<?php echo e(route('scope-of-delivery.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row g-2">
                        <div class="col mb-3">
                            <label for="name" class="form-label required">Name</label>
                            <input type="text" required id="name" name="name" class="form-control"
                                placeholder="Enter Scope of Delivery Name">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/scope-of-delivery/create.blade.php ENDPATH**/ ?>