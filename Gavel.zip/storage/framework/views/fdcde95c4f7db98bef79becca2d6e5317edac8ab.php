


<?php $__env->startPush('styles'); ?>
    <style>
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">
                Product /</span> Update product
        </h4>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">Product Details & update</h5>
                    <form method="POST" action="<?php echo e(route('product.update')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                        <div class="card-body">
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="name" class="form-label required">name</label>
                                    <input class="form-control" type="text" name="name" id="name"
                                        placeholder="Name" required value="<?php echo e($product->name); ?>" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="category_id">Select a Category</label>
                                    <select id="category_id" class="select2 form-select" name="category_id" required>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"
                                                <?php if($category->id == $product->category->id): ?> selected <?php endif; ?>><?php echo e($category->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="images" class="form-label optional">Image</label>
                                    <div class="row">
                                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mx-auto text-center col-4">
                                                <a href="<?php echo e($image); ?>" data-lightbox="<?php echo e($product->name); ?>"
                                                    data-title="<?php echo e($product->name); ?>">
                                                    <img src="<?php echo e(asset($image)); ?>" alt="product image" class="m-2"
                                                        width="100" height="100">
                                                </a>
                                                <button type="button"
                                                    class="mx-auto text-center mb-3 btn btn-sm btn-outline-danger mx-2 productOneImageDelete"
                                                    data-productId="<?php echo e($product->id); ?>" data-image="<?php echo e($image); ?>">
                                                    <i class="bx bx-trash px-0"></i>
                                                </button>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <input class="form-control" type="file" name="images[]" id="images"
                                        placeholder="Upload product images" multiple />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="condition">Condition</label>
                                    <select id="condition" class="select2 form-select" required name="condition">
                                        <?php $__currentLoopData = $conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($product->condition_id == $condition->id): ?> selected <?php endif; ?>
                                                value="<?php echo e($condition->id); ?>"><?php echo e($condition->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="case_diameter" class="form-label optional">Case Diameter <span
                                            class="text-lowercase">(mm)</span></label>
                                    <input class="form-control" type="number" name="case_diameter" id="case_diameter"
                                        placeholder="Input product case diameter" value="<?php echo e($product->case_diameter); ?>" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="lug_width" class="form-label optional">Lug width <span
                                            class="text-lowercase">(mm)</span></label>
                                    <input class="form-control" type="number" name="lug_width" id="lug_width"
                                        placeholder="Input product lug width" value="<?php echo e($product->lug_width); ?>" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="scope_of_delivery">Scope of Delivery</label>
                                    <select id="scope_of_delivery" class="select2 form-select" required
                                        name="scope_of_delivery">
                                        <?php $__currentLoopData = $scope_of_deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scope_of_delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($product->scope_of_delivery_id == $scope_of_delivery->id): ?> selected <?php endif; ?>
                                                value="<?php echo e($scope_of_delivery->id); ?>"><?php echo e($scope_of_delivery->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="year_of_production">Year of production</label>
                                    <select id="year_of_production" class="select2 form-select" name="year_of_production">
                                        <option value="2022" <?php if($category->year_of_production == '2022'): ?> selected <?php endif; ?>>2022
                                        </option>
                                        <option value="2023" <?php if($category->year_of_production == '2023'): ?> selected <?php endif; ?>>2023
                                        </option>
                                        <option value="unknown" <?php if($category->year_of_production == 'unknown'): ?> selected <?php endif; ?>>Unknown
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="movement" class="form-label required">Movement</label>
                                    <select id="movement" class="select2 form-select" required name="movement">
                                        <?php $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($product->movement_id == $movement->id): ?> selected <?php endif; ?>
                                                value="<?php echo e($movement->id); ?>"><?php echo e($movement->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label class="form-label optional" for="status">Status</label>
                                    <select id="status" class="select2 form-select" name="status">
                                        <option value="active" <?php if($category->status == 'active'): ?> selected <?php endif; ?>>Active
                                        </option>
                                        <option value="inactive" <?php if($category->status == 'inactive'): ?> selected <?php endif; ?>>
                                            Inactive
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="starting_bid" class="form-label required">Starting bid</label>
                                    <input class="form-control" type="number" name="starting_bid" id="starting_bid"
                                        placeholder="Enter starting bid" required value="<?php echo e($product->starting_bid); ?>" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="increment" class="form-label optional">increment</label>
                                    <input class="form-control" type="number" value="1000" name="increment"
                                        id="increment" placeholder="Enter increment bid"
                                        value="<?php echo e($product->increment); ?>" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="start_date" class="form-label required">Start Date</label>
                                    <input type="date" required id="start_date" name="start_date"
                                        class="form-control product_start_date" placeholder="Enter Start Date"
                                        value="<?php echo e($product->start_date); ?>">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="end_date" class="form-label required">End Date</label>
                                    <input type="date" required id="end_date" name="end_date"
                                        class="form-control product_end_date" placeholder="Enter End Date"
                                        value="<?php echo e($product->end_date); ?>">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="verified_status" class="form-label required">Verified status</label>
                                    <select id="verified_status" class="select2 form-select" name="verified_status">
                                        <option value="pending" <?php if($product->verified_status == 'pending'): ?> selected <?php endif; ?>>Pending
                                        </option>
                                        <option value="accepted" <?php if($product->verified_status == 'accepted'): ?> selected <?php endif; ?>>
                                            Accepted
                                        </option>
                                        <option value="rejected" <?php if($product->verified_status == 'rejected'): ?> selected <?php endif; ?>>
                                            Rejected
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="description" class="form-label optional">description</label>
                                    <textarea id="description" class="form-control" rows="4" name="description"
                                        value="<?php echo e($product->description); ?>" placeholder="Enter product description"></textarea>
                                </div>
                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary me-2">Submit</button>
                                <a href="<?php echo e(route('product.index')); ?>" class="btn btn-outline-secondary mx-1"><i
                                        class='bx bx-arrow-back'></i> Back to product List</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/product/edit.blade.php ENDPATH**/ ?>