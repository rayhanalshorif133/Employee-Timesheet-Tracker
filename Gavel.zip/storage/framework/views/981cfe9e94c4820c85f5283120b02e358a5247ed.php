


<?php $__env->startPush('styles'); ?>
<style>
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
        

    <h4 class="fw-bold py-3 mb-4">
        <span class="text-muted fw-light">Products /</span> Product Pending List
    </h4>

    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between">
                <h5>Products List</h5>
                <a href="<?php echo e(route('product.create')); ?>">
                <button class="btn btn-sm btn-outline-primary">Add New</button>
                </a>
            </div>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Reference Number</th>
                        <th>Name</th>
                        <th>Category Name</th>
                        <th>Condition</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($product->reference_number); ?></td>
                            <td><?php echo e($product->name ? $product->name : "Not Set"); ?></td>
                            <td><?php echo e($product->category->name); ?></td>
                            <td><?php echo e($product->condition); ?></td>
                            <td>
                                <div class="btn-group" role="group" aria-label="Basic example"
                                        data-url="<?php echo e(route('product.delete', $product->id)); ?>">
                                        <a class="btn btn-outline-success btn-sm" href="<?php echo e(route('product.show',$product->id)); ?>">
                                            <i class="bx bxs-show"></i>
                                        </a>
                                        <a class="btn btn-outline-info btn-sm" data-id="<?php echo e($product->id); ?>"
                                            href="<?php echo e(route('product.edit', $product->id)); ?>">
                                            <i class="bx bx-edit-alt"></i>
                                        </a>
                                        <a class="btn btn-outline-danger btn-sm itemDeleteBtn"
                                            href="javascript:void(0);">
                                            <i class="bx bx-trash"></i>
                                        </a>
                                    </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/product/pending_Index.blade.php ENDPATH**/ ?>