


<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        

        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Conditions /</span> Conditions List
        </h4>

        <!-- Hoverable Table rows -->
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5>Conditions List</h5>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#createNewCondition">Add New</button>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="text-center">Name</th>
                            <th class="text-center">Added By</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td class="name w-25"><?php echo e($condition->name); ?></td>
                                <td class="nameInput d-none">
                                    <input type="text" class="form-control" id="name" value="<?php echo e($condition->name); ?>" placeholder="Enter Name">
                                </td>
                                <td><span class="badge bg-label-primary addedByName"><?php echo e($condition->addedBy->username); ?></span></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example" data-url="<?php echo e(route('condition.delete',$condition->id)); ?>">
                                        <a class="btn btn-outline-info btn-sm itemEditBtn" data-id="<?php echo e($condition->id); ?>" href="javascript:void(0);" data-url="<?php echo e(route('condition.update')); ?>">
                                            <i class="bx bx-edit-alt"></i>
                                        </a>
                                        <a class="btn btn-outline-danger btn-sm itemDeleteBtn"  href="javascript:void(0);">
                                            <i class="bx bx-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php echo $__env->make('condition.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/condition/index.blade.php ENDPATH**/ ?>