<div class="modal fade" id="viewCategory" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewCategoryTitle">
                    Category Detials
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <hr class="my-1" />
            <div class="modal-body">
                <div class="row">
                    <div class="col-12">
                        <img src="" alt="Category image" class="img-fluid viewCategoryImage">
                    </div>
                    <div class="col-12 my-3">
                        <span class="fw-bold mx-2">Name:</span><span class="viewCategoryName"></span>
                    </div>
                    <div class="col-12 mb-3">
                        <span class="fw-bold mx-2">Start Date:</span><span class="viewCategoryStartDate"></span>
                        <strong class="fw-bold text-info mx-2">And</strong>
                        <span class="fw-bold mx-2">End Date:</span><span class="viewCategoryEndDate"></span>
                    </div>
                    
                    <div class="col-12 mb-3">
                        <span class="fw-bold mx-2">Status:</span><span class="viewCategoryStatus"></span>
                    </div>
                    <div class="col-12 mb-3">
                        <span class="fw-bold mx-2">Type:</span>
                        <span class="viewCategoryType badge me-1"></span>
                    </div>
                    <div class="col-12 mb-3">
                        <span class="fw-bold mx-2">Details:</span>
                        <br/><span class="viewCategoryDescription px-2"></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Ok</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/category/view.blade.php ENDPATH**/ ?>