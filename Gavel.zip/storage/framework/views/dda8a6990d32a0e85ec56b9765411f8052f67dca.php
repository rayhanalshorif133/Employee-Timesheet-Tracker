


<?php $__env->startPush('styles'); ?>
    <style>
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Payments /</span> Payment List
        </h4>

        <!-- Hoverable Table rows -->
        <div class="card">
            <h5 class="card-header">Payment List</h5>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Invoice no</th>
                            <th>Product Name</th>
                            <th>User name</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->index + 1); ?></td>
                                <td><span class="badge bg-label-info me-1"><?php echo e($payment->invoice_no); ?></span></td>
                                <td>
                                    <a href="<?php echo e(route('product.show', $payment->product->id)); ?>">
                                        <?php echo e($payment->product->name ? $payment->product->name : $payment->product->model); ?>

                                    </a>
                                </td>
                                <td>
                                    <a
                                        href="<?php echo e(route('user.edit', $payment->user->id)); ?>"><?php echo e($payment->user->username ? $payment->user->username : $payment->user->phone); ?>

                                    </a>
                                </td>
                                <td><?php echo e($payment->amount); ?></td>
                                <td><span class="badge bg-label-primary me-1"><?php echo e($payment->payment_status); ?></span></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a class="btn btn-outline-success btn-sm" target="_blank"
                                            href="<?php echo e($payment->invoice_download_link); ?>">
                                            <i class="bx bxs-show"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/payment/index.blade.php ENDPATH**/ ?>