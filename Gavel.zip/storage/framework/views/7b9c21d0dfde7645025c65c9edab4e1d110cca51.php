<div class="modal fade" id="createNewCategory" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">
                    Create New Category
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="<?php echo e(route('category.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row g-2">
                        <div class="col mb-3">
                            <label for="name" class="form-label required">Name</label>
                            <input type="text" required id="name" name="name" class="form-control"
                                placeholder="Enter Category Name">
                        </div>
                        <div class="col mb-3">
                            <label for="image" class="form-label required">Image</label>
                            <input type="file" required id="image" name="image" class="form-control"
                                placeholder="Upload Category Image">
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-3">
                            <label for="start_date" class="form-label required">Start Date</label>
                            <input type="date" required id="start_date" name="start_date" class="form-control category_start_date"
                                placeholder="Enter Start Date">
                        </div>
                        <div class="col mb-3">
                            <label for="end_date" class="form-label required">End Date</label>
                            <input type="date" required id="end_date" name="end_date" class="form-control category_end_date"
                                placeholder="Enter End Date">
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-3">
                            <label for="status" class="form-label required">Status</label>
                            <select id="status" class="select2 form-select" required name="status">
                                <option value="" selected disabled>Select Status</option>
                                <option value="scheduled">Scheduled</option>
                                <option value="running">Running</option>
                            </select>
                        </div>
                        <div class="col mb-3">
                            <label for="type" class="form-label optional">Type</label>
                            <select id="type" class="select2 form-select" name="type">
                                <option value="" selected disabled>Select Type</option>
                                <option value="gavel_it">Gavel It</option>
                                <option value="gaveled">Gaveled</option>
                            </select>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <label for="description" class="form-label optional">description</label>
                        <textarea id="description" class="form-control" rows="4" name="description" placeholder="Enter Category Description"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/category/create.blade.php ENDPATH**/ ?>