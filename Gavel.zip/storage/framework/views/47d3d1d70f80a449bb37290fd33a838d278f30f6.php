


<?php $__env->startPush('styles'); ?>
    <style>
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Products /</span> <span class="text-muted fw-light"><?php echo e($product->name); ?>

                /</span> Product Details
        </h4>
        <div class="card my-2 py-0">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5 class="mt-2">Product's Details</h5>
                    <a href="<?php echo e(route('product.index')); ?>" class="mt-2">
                        <button class="btn btn-sm btn-outline-danger">Back</button>
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="carousel-item <?php if($key == 0): ?> active <?php endif; ?>">
                                        <img class="d-block w-100" src="<?php echo e($image); ?>" alt="First slide">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <a class="carousel-control-prev" href="#carouselExample" role="button" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon bg-info" aria-hidden="true"></span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExample" role="button" data-bs-slide="next">
                                <span class="carousel-control-next-icon bg-info" aria-hidden="true"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="my-4">Product Information</h5>
                        <hr />
                        <strong class="mx-1">Reference number:</strong><span><?php echo e($product->reference_number); ?></span>
                        <br />
                        <strong class="mx-1">Name:</strong><span><?php echo e($product->name); ?></span><br />
                        <strong class="mx-1">Condition:</strong><span><?php echo e($product->condition); ?></span><br />
                        <strong class="mx-1">Scope of
                            delivery:</strong><span><?php echo e($product->scope_of_delivery); ?></span><br />
                        <strong class="mx-1">Year of
                            production:</strong><span><?php echo e($product->year_of_production); ?></span><br />
                        <strong class="mx-1">Case diameter:</strong><span><?php echo e($product->case_diameter); ?></span><br />
                        <strong class="mx-1">Case diameter:</strong><span><?php echo e($product->case_diameter); ?></span><br />
                        <strong class="mx-1">Lug width:</strong><span><?php echo e($product->lug_width); ?></span><br />
                        <strong class="mx-1">Current bid:</strong><span><?php echo e($product->current_bid); ?></span><br />
                        <strong class="mx-1">Increment:</strong><span><?php echo e($product->increment); ?></span><br />
                        <strong class="mx-1">Start date:</strong><span><?php echo e($product->start_date); ?></span><br />
                        <strong class="mx-1">End date:</strong><span><?php echo e($product->end_date); ?></span><br />
                        <strong class="mx-1">Status:</strong><span><?php echo e($product->status); ?></span><br />
                        <strong class="mx-1">Description:</strong><br />
                        <span class="mx-1">
                            <?php echo e($product->description); ?>

                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Rayhan\Practice\Gavel\resources\views/product/show.blade.php ENDPATH**/ ?>