@extends('layouts.app')

{{-- styles --}}
@push('styles')
    <style>
    </style>
@endpush

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">

        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Movements /</span> Movement List
        </h4>

        <!-- Hoverable Table rows -->
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5>Movements List</h5>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                        data-bs-target="#createNewMovement">Add New</button>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="text-center">Name</th>
                            <th class="text-center">Added By</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        @foreach ($movements as $movement)
                            <tr class="text-center">
                                <td>{{ $loop->index + 1 }}</td>
                                <td class="name w-25">{{ $movement->name }}</td>
                                <td class="nameInput d-none">
                                    <input type="text" class="form-control" id="name" value="{{ $movement->name }}"
                                        placeholder="Enter Name">
                                </td>
                                <td><span
                                        class="badge bg-label-primary addedByName">{{ $movement->addedBy->username }}</span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example"
                                        data-url="{{ route('movement.delete', $movement->id) }}">
                                        <a class="btn btn-outline-info btn-sm itemEditBtn" data-id="{{ $movement->id }}"
                                            href="javascript:void(0);" data-url="{{ route('movement.update') }}">
                                            <i class="bx bx-edit-alt"></i>
                                        </a>
                                        <a class="btn btn-outline-danger btn-sm itemDeleteBtn" href="javascript:void(0);">
                                            <i class="bx bx-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    @include('movement.create')
@endsection

{{-- scripts --}}
@push('scripts')
@endpush
