@extends('layouts.app')

{{-- styles --}}
@push('styles')
    <style>
    </style>
@endpush

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Payments /</span> Payment List
        </h4>

        <!-- Hoverable Table rows -->
        <div class="card">
            <h5 class="card-header">Payment List</h5>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Invoice no</th>
                            <th>Product Name</th>
                            <th>User name</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        @foreach ($payments as $payment)
                            <tr>
                                <td>{{ $loop->index + 1 }}</td>
                                <td><span class="badge bg-label-info me-1">{{ $payment->invoice_no }}</span></td>
                                <td>
                                    <a href="{{ route('product.show', $payment->product->id) }}">
                                        {{ $payment->product->name ? $payment->product->name : $payment->product->model }}
                                    </a>
                                </td>
                                <td>
                                    <a
                                        href="{{ route('user.edit', $payment->user->id) }}">{{ $payment->user->username ? $payment->user->username : $payment->user->phone }}
                                    </a>
                                </td>
                                <td>{{ $payment->amount }}</td>
                                <td><span class="badge bg-label-primary me-1">{{ $payment->payment_status }}</span></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a class="btn btn-outline-success btn-sm" target="_blank"
                                            href="{{ $payment->invoice_download_link }}">
                                            <i class="bx bxs-show"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

{{-- scripts --}}
@push('scripts')
@endpush
