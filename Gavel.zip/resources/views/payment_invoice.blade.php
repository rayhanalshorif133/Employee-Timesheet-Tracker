<!DOCTYPE html>
<html>

<head>
    <title>Invoice</title>

    <style>
        .px-8 {
            padding-left: 2rem;
            padding-right: 2rem;
        }

        .w-full {
            width: 100%;
        }

        .w- {
            width: 60%;
        }

        .w-2\/5 {
            width: 40%;
        }

        .w-1\/2 {
            width: 50%;
        }

        .h-10 {
            height: 2.5rem;
        }

        .bg-yellow-700 {
            background-color: #FBBF24;
        }

        .mx-5 {
            margin-left: 1.25rem;
            margin-right: 1.25rem;
        }

        .text-3xl {
            font-size: 1.875rem;
        }

        .font-light {
            font-weight: 300;
        }

        .font-normal {
            font-weight: 400;
        }

        .font-medium {
            font-weight: 500;
        }

        .font-semibold {
            font-weight: 600;
        }

        .font-bold {
            font-weight: 700;
        }

        .mx-auto {
            margin-left: auto;
            margin-right: auto;
        }

        .text-center {
            text-align: center;
        }

        .text-gray-800 {
            color: #1F2937;
        }

        .uppercase {
            text-transform: uppercase;
        }

        .capitalize {
            text-transform: capitalize;
        }

        .normal-case {
            text-transform: none;
        }

        .bg-white {
            background-color: #fff;
        }

        .px-2 {
            padding-left: 0.5rem;
            padding-right: 0.5rem;
        }

        .py-5 {
            padding-top: 1.25rem;
            padding-bottom: 1.25rem;
        }

        .tracking-widest {
            letter-spacing: 0.1em;
        }

        .text-2xl {
            font-size: 1.5rem;
            line-height: 2rem;
        }

        .text-xl {
            font-size: 1.25rem;
        }

        .text-base {
            font-size: 1rem;
        }

        .text-lg {
            font-size: 1.125rem;
        }

        .text-gray-700 {
            color: #555d5c;
        }

        .tracking-normal {
            letter-spacing: 0;
        }

        .tracking-wider {
            letter-spacing: 0.05em;
        }

        .py-0 {
            padding-top: 0;
            padding-bottom: 0;
        }

        .my-2 {
            margin-top: 0.5rem;
            margin-bottom: 0.5rem;
        }

        .bg-gray-800 {
            background-color: #373B46;
        }

        .text-white {
            color: #fff;
        }

        .py-2 {
            padding-top: 0.5rem;
            padding-bottom: 0.5rem;
        }

        .text-gray-200 {
            color: rgb(229 231 235);
        }

        .text-sm {
            font-size: 0.875rem;
        }

        .bg-slate-200 {
            background-color: #F2F2F2;
        }

        .-yellow {
            -yellow-width: 1px;
        }

        .-yellow-slate-400 {
            border-color: rgb(148 163 184);
        }
        .text-right{
            text-align: right;
        }

        .w-10{	width: 2.5rem; /* 40px */}
        .mt-5{
            margin-top: 1.25rem;
        }
        .px-5{
            padding-left: 1.25rem;
            padding-right: 1.25rem;
        }
        .text-start{
            text-align: start;
        }
        .bg-gray-700{
            background-color: #454a4e;
        }
        .bg-gray-300{
            background-color: #d1d5db;
        }
        .bg-gray-100{
            background-color: #f9fafb;
        }
        .border-yellow{
            border: 2px solid #FBBF24;
        }
        .mt-20{
            margin-top: 5rem;
        }
        .absolute{
            position: absolute;
        }
        .bottom-5{
            bottom: 1.25rem;
        }
        .left-0{
            left: 0;
        }
        .right-0{
            right: 0;
        }
    </style>

</head>

<body class="">
    <div class="w-full px-8">
        <img src="./images/gavel_logo.png" alt="logo" width="250" height="120">
    </div>
    <div class="w-full text-center mx-auto">
        <div class="w-2/5 h-10 bg-yellow-700 text-3xl font-bold text-gray-800 uppercase">
            <span class="bg-white px-2 py-5">Invoice</span>
        </div>
    </div>
    <div class="w-full px-8">
        <h3 class="tracking-widest text-2xl py-0 my-2">Invoice to:</h3>
        <span
            class="font-bold text-xl text-gray-700 tracking-widest">{{ $user->username ? $user->username : $user->full_name }}</span><br />
        <span
            class="font-medium text-base text-gray-700 tracking-widest">{{ $user->email ? $user->email : $user->nationality }}</span><br />
        <span
            class="font-medium text-base text-gray-700 tracking-widest">{{ $user->phone ? $user->phone : $user->issuing_country }}</span><br />
        <h3 class="tracking-wider text-base py-0 my-2">Invoice#
            <span class="font-medium text-base text-gray-700 tracking-normal">{{ $invoice_no }}</span>
        </h3>
        <h3 class="tracking-wider text-base py-0 my-2">Date#
            <span class="font-medium text-base text-gray-700 tracking-normal">{{ $date }}</span>
        </h3>
    </div>
    <div class="w-full">
        <table class="w-full border border-slate-400">
            <thead class="bg-gray-800 h-10">
                <tr>
                    <th class="text-lg text-gray-200 uppercase py-2 tracking-widest">SL.</th>
                    <th class="text-lg text-gray-200 uppercase py-2 tracking-widest">Item Information</th>
                    <th class="text-lg text-gray-200 uppercase py-2 tracking-widest">Price</th>
                    <th class="text-lg text-gray-200 uppercase py-2 tracking-widest">Qty</th>
                    <th class="text-lg text-gray-200 uppercase py-2 tracking-widest">Total</th>
                </tr>
            </thead>
            <tbody>
                <tr class="bg-slate-200 h-10">
                    <td class="text-lg text-gray-800 capitalize py-2 tracking-widest text-center mx-auto">1</td>
                    <td class="text-lg text-gray-800 capitalize py-2 tracking-widest text-center mx-auto">
                        {{ $product->name ? $product->name : $product->model }}
                        <br />
                        <span class="text-sm text-center mx-auto">
                            {{ $product->description }}
                        </span>
                    </td>
                    <td class="text-lg text-gray-800 capitalize py-2 tracking-widest text-center mx-auto">
                        {{ $amount }}</td>
                    <td class="text-lg text-gray-800 capitalize py-2 tracking-widest text-center mx-auto">1</td>
                    <td class="text-lg text-gray-800 capitalize py-2 tracking-widest text-center mx-auto">
                        {{ $amount }}</td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="w-full text-right mx-auto mt-5">
        <div class="w-full h-10">
            <span class="px-5 py-2 bg-yellow-700 text-gray-800 text-lg font-bold uppercase"> Total: {{ $amount }} AED</span>
        </div>
    </div>
    <div class="w-full text-start absolute bottom-5 left-0 right-0">
        <div class="w-full h-10">
            <span class="px-5 py-2 tracking-widest bg-gray-100 text-gray-800 text-lg font-bold uppercase border-yellow">
                Thank you for your business
            </span>
        </div>
    </div>
</body>

</html>
