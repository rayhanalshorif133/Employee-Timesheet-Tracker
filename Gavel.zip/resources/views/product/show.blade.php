@extends('layouts.app')

{{-- styles --}}
@push('styles')
    <style>
    </style>
@endpush

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Products /</span> <span class="text-muted fw-light">{{ $product->name }}
                /</span> Product Details
        </h4>
        <div class="card my-2 py-0">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5 class="mt-2">Product's Details</h5>
                    <a href="{{ route('product.index') }}" class="mt-2">
                        <button class="btn btn-sm btn-outline-danger">Back</button>
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                @foreach ($product->images as $key => $image)
                                    <div class="carousel-item @if ($key == 0) active @endif">
                                        <img class="d-block w-100" src="{{ $image }}" alt="First slide">
                                    </div>
                                @endforeach
                            </div>
                            <a class="carousel-control-prev" href="#carouselExample" role="button" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon bg-info" aria-hidden="true"></span>
                            </a>
                            <a class="carousel-control-next" href="#carouselExample" role="button" data-bs-slide="next">
                                <span class="carousel-control-next-icon bg-info" aria-hidden="true"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="my-4">Product Information</h5>
                        <hr />
                        <strong class="mx-1">Reference number:</strong><span>{{ $product->reference_number }}</span>
                        <br />
                        <strong class="mx-1">Name:</strong><span>{{ $product->name }}</span><br />
                        <strong class="mx-1">Condition:</strong><span>{{ $product->condition }}</span><br />
                        <strong class="mx-1">Scope of
                            delivery:</strong><span>{{ $product->scope_of_delivery }}</span><br />
                        <strong class="mx-1">Year of
                            production:</strong><span>{{ $product->year_of_production }}</span><br />
                        <strong class="mx-1">Case diameter:</strong><span>{{ $product->case_diameter }}</span><br />
                        <strong class="mx-1">Case diameter:</strong><span>{{ $product->case_diameter }}</span><br />
                        <strong class="mx-1">Lug width:</strong><span>{{ $product->lug_width }}</span><br />
                        <strong class="mx-1">Current bid:</strong><span>{{ $product->current_bid }}</span><br />
                        <strong class="mx-1">Increment:</strong><span>{{ $product->increment }}</span><br />
                        <strong class="mx-1">Start date:</strong><span>{{ $product->start_date }}</span><br />
                        <strong class="mx-1">End date:</strong><span>{{ $product->end_date }}</span><br />
                        <strong class="mx-1">Status:</strong><span>{{ $product->status }}</span><br />
                        <strong class="mx-1">Description:</strong><br />
                        <span class="mx-1">
                            {{ $product->description }}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div>
@endsection

{{-- scripts --}}
@push('scripts')
@endpush
