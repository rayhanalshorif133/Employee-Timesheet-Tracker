@extends('layouts.app')

{{-- styles --}}
@push('styles')
<style>
</style>
@endpush

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
        

    <h4 class="fw-bold py-3 mb-4">
        <span class="text-muted fw-light">Products /</span> Product List
    </h4>

    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between">
                <h5>Products List</h5>
                <a href="{{route('product.create')}}">
                <button class="btn btn-sm btn-outline-primary">Add New</button>
                </a>
            </div>
        </div>
        <div class="table-responsive text-nowrap">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Reference Number</th>
                        <th>Name</th>
                        <th>Category Name</th>
                        <th>Condition</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    @foreach ($products as $product)
                        <tr>
                            <td>{{ $loop->index + 1 }}</td>
                            <td>{{ $product->reference_number }}</td>
                            <td>{{ $product->name ? $product->name : "Not Set" }}</td>
                            <td>{{ $product->category->name }}</td>
                            <td>{{ $product->condition }}</td>
                            <td>
                                <div class="btn-group" role="group" aria-label="Basic example"
                                        data-url="{{ route('product.delete', $product->id) }}">
                                        <a class="btn btn-outline-success btn-sm" href="{{route('product.show',$product->id)}}">
                                            <i class="bx bxs-show"></i>
                                        </a>
                                        <a class="btn btn-outline-info btn-sm" data-id="{{ $product->id }}"
                                            href="{{ route('product.edit', $product->id) }}">
                                            <i class="bx bx-edit-alt"></i>
                                        </a>
                                        <a class="btn btn-outline-danger btn-sm itemDeleteBtn"
                                            href="javascript:void(0);">
                                            <i class="bx bx-trash"></i>
                                        </a>
                                    </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

{{-- scripts --}}
@push('scripts')

@endpush

