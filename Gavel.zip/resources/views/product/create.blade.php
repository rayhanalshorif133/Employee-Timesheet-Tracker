@extends('layouts.app')

{{-- styles --}}
@push('styles')
    <style>
    </style>
@endpush

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">
                Product /</span> Create new product
        </h4>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">Product Details & Create</h5>
                    <form method="POST" action="{{ route('product.store') }}" enctype="multipart/form-data">
                        @csrf
                        <div class="card-body">
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="name" class="form-label required">name</label>
                                    <input class="form-control" type="text" name="name" id="name"
                                        placeholder="Name" required />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="category_id">Select a Category</label>
                                    <select id="category_id" class="select2 form-select" name="category_id" required>
                                        <option value="" selected disabled>select a category</option>
                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="images" class="form-label required">Image</label>
                                    <input class="form-control" type="file" name="images[]" id="images"
                                        placeholder="Upload product images" required multiple />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="condition">Condition</label>
                                    <select id="condition" class="select2 form-select" required name="condition">
                                        <option value="" selected disabled>select a condition</option>
                                        @foreach ($conditions as $condition)
                                            <option value="{{ $condition->id }}">{{ $condition->name }}</option>
                                        @endforeach
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="case_diameter" class="form-label optional">Case Diameter <span
                                            class="text-lowercase">(mm)</span></label>
                                    <input class="form-control" type="number" name="case_diameter" id="case_diameter"
                                        placeholder="Input product case diameter" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="lug_width" class="form-label optional">Lug width <span
                                            class="text-lowercase">(mm)</span></label>
                                    <input class="form-control" type="number" name="lug_width" id="lug_width"
                                        placeholder="Input product lug width" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="scope_of_delivery">Scope of Delivery</label>
                                    <select id="scope_of_delivery" class="select2 form-select" required name="scope_of_delivery">
                                        <option value="" selected disabled>select a scope of delivery</option>
                                        @foreach ($scope_of_deliveries as $scope_of_delivery)
                                            <option value="{{ $scope_of_delivery->id }}">{{ $scope_of_delivery->name }}
                                            </option>
                                        @endforeach
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label optional" for="year_of_production">Year of production</label>
                                    <select id="year_of_production" class="select2 form-select" name="year_of_production">
                                        <option value="" selected disabled>select a production's year</option>
                                        <option value="unknown">Unknown</option>
                                        <option value="2022">2022</option>
                                        <option value="2023">2023</option>
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="movement" class="form-label required">Movement</label>
                                    <select id="movement" class="select2 form-select" required name="movement">
                                        <option value="" selected disabled>select a movements</option>
                                        @foreach ($movements as $movement)
                                            <option value="{{ $movement->id }}">{{ $movement->name }}
                                            </option>
                                        @endforeach
                                        </option>
                                    </select>
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label class="form-label optional" for="status">Status</label>
                                    <select id="status" class="select2 form-select" name="status">
                                        <option value="active" selected>Active</option>
                                        <option value="inactive">Inactive</option>
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="starting_bid" class="form-label required">Starting bid</label>
                                    <input class="form-control" type="number" name="starting_bid" id="starting_bid"
                                        placeholder="Enter starting bid" required />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="increment" class="form-label optional">increment</label>
                                    <input class="form-control" type="number" value="1000" name="increment"
                                        id="increment" placeholder="Enter increment bid" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="start_date" class="form-label required">Start Date</label>
                                    <input type="date" required id="start_date" name="start_date"
                                        class="form-control product_start_date" placeholder="Enter Start Date">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="end_date" class="form-label required">End Date</label>
                                    <input type="date" required id="end_date" name="end_date"
                                        class="form-control product_end_date" placeholder="Enter End Date">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="description" class="form-label optional">description</label>
                                    <textarea id="description" class="form-control" rows="4" name="description"
                                        placeholder="Enter product description"></textarea>
                                </div>
                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary me-2">Submit</button>
                                <a href="{{ route('product.index') }}" class="btn btn-outline-secondary mx-1"><i
                                        class='bx bx-arrow-back'></i> Back to product List</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

{{-- scripts --}}
@push('scripts')
@endpush
