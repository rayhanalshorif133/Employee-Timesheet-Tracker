@extends('layouts.app')

{{-- styles --}}
@push('styles')
    <style>
    </style>
@endpush

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">
                Product /</span> Update product
        </h4>
        <div class="row">
            <div class="col-md-12">
                <div class="card mb-4">
                    <h5 class="card-header">Product Details & update</h5>
                    <form method="POST" action="{{ route('product.update') }}" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="id" value="{{ $product->id }}">
                        <div class="card-body">
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="name" class="form-label required">name</label>
                                    <input class="form-control" type="text" name="name" id="name"
                                        placeholder="Name" required value="{{ $product->name }}" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="category_id">Select a Category</label>
                                    <select id="category_id" class="select2 form-select" name="category_id" required>
                                        @foreach ($categories as $category)
                                            <option value="{{ $category->id }}"
                                                @if ($category->id == $product->category->id) selected @endif>{{ $category->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="images" class="form-label optional">Image</label>
                                    <div class="row">
                                        @foreach ($product->images as $image)
                                            <div class="mx-auto text-center col-4">
                                                <a href="{{ $image }}" data-lightbox="{{ $product->name }}"
                                                    data-title="{{ $product->name }}">
                                                    <img src="{{ asset($image) }}" alt="product image" class="m-2"
                                                        width="100" height="100">
                                                </a>
                                                <button type="button"
                                                    class="mx-auto text-center mb-3 btn btn-sm btn-outline-danger mx-2 productOneImageDelete"
                                                    data-productId="{{ $product->id }}" data-image="{{ $image }}">
                                                    <i class="bx bx-trash px-0"></i>
                                                </button>
                                            </div>
                                        @endforeach
                                    </div>
                                    <input class="form-control" type="file" name="images[]" id="images"
                                        placeholder="Upload product images" multiple />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="condition">Condition</label>
                                    <select id="condition" class="select2 form-select" required name="condition">
                                        @foreach ($conditions as $condition)
                                            <option @if ($product->condition_id == $condition->id) selected @endif
                                                value="{{ $condition->id }}">{{ $condition->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="case_diameter" class="form-label optional">Case Diameter <span
                                            class="text-lowercase">(mm)</span></label>
                                    <input class="form-control" type="number" name="case_diameter" id="case_diameter"
                                        placeholder="Input product case diameter" value="{{ $product->case_diameter }}" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="lug_width" class="form-label optional">Lug width <span
                                            class="text-lowercase">(mm)</span></label>
                                    <input class="form-control" type="number" name="lug_width" id="lug_width"
                                        placeholder="Input product lug width" value="{{ $product->lug_width }}" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="scope_of_delivery">Scope of Delivery</label>
                                    <select id="scope_of_delivery" class="select2 form-select" required
                                        name="scope_of_delivery">
                                        @foreach ($scope_of_deliveries as $scope_of_delivery)
                                            <option @if ($product->scope_of_delivery_id == $scope_of_delivery->id) selected @endif
                                                value="{{ $scope_of_delivery->id }}">{{ $scope_of_delivery->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label class="form-label required" for="year_of_production">Year of production</label>
                                    <select id="year_of_production" class="select2 form-select" name="year_of_production">
                                        <option value="2022" @if ($category->year_of_production == '2022') selected @endif>2022
                                        </option>
                                        <option value="2023" @if ($category->year_of_production == '2023') selected @endif>2023
                                        </option>
                                        <option value="unknown" @if ($category->year_of_production == 'unknown') selected @endif>Unknown
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="movement" class="form-label required">Movement</label>
                                    <select id="movement" class="select2 form-select" required name="movement">
                                        @foreach ($movements as $movement)
                                            <option @if ($product->movement_id == $movement->id) selected @endif
                                                value="{{ $movement->id }}">{{ $movement->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label class="form-label optional" for="status">Status</label>
                                    <select id="status" class="select2 form-select" name="status">
                                        <option value="active" @if ($category->status == 'active') selected @endif>Active
                                        </option>
                                        <option value="inactive" @if ($category->status == 'inactive') selected @endif>
                                            Inactive
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="starting_bid" class="form-label required">Starting bid</label>
                                    <input class="form-control" type="number" name="starting_bid" id="starting_bid"
                                        placeholder="Enter starting bid" required value="{{ $product->starting_bid }}" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="increment" class="form-label optional">increment</label>
                                    <input class="form-control" type="number" value="1000" name="increment"
                                        id="increment" placeholder="Enter increment bid"
                                        value="{{ $product->increment }}" />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="start_date" class="form-label required">Start Date</label>
                                    <input type="date" required id="start_date" name="start_date"
                                        class="form-control product_start_date" placeholder="Enter Start Date"
                                        value="{{ $product->start_date }}">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="end_date" class="form-label required">End Date</label>
                                    <input type="date" required id="end_date" name="end_date"
                                        class="form-control product_end_date" placeholder="Enter End Date"
                                        value="{{ $product->end_date }}">
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="verified_status" class="form-label required">Verified status</label>
                                    <select id="verified_status" class="select2 form-select" name="verified_status">
                                        <option value="pending" @if ($product->verified_status == 'pending') selected @endif>Pending
                                        </option>
                                        <option value="accepted" @if ($product->verified_status == 'accepted') selected @endif>
                                            Accepted
                                        </option>
                                        <option value="rejected" @if ($product->verified_status == 'rejected') selected @endif>
                                            Rejected
                                        </option>
                                    </select>
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="description" class="form-label optional">description</label>
                                    <textarea id="description" class="form-control" rows="4" name="description"
                                        value="{{ $product->description }}" placeholder="Enter product description"></textarea>
                                </div>
                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary me-2">Submit</button>
                                <a href="{{ route('product.index') }}" class="btn btn-outline-secondary mx-1"><i
                                        class='bx bx-arrow-back'></i> Back to product List</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection

{{-- scripts --}}
@push('scripts')
@endpush
