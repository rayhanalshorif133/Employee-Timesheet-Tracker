@extends('layouts.app')

{{-- styles --}}
@push('styles')
<style>
</style>
@endpush

@section('content')
<div class="container-xxl flex-grow-1 container-p-y"></div>
@endsection

{{-- scripts --}}
@push('scripts')

@endpush

