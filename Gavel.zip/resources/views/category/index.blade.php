@extends('layouts.app')

{{-- styles --}}
@push('styles')
    <style>
    </style>
@endpush

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        

        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Categories /</span> Category List
        </h4>

        <!-- Hoverable Table rows -->
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5>Categories List</h5>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#createNewCategory">Add New</button>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Count of Products</th>
                            <th>Status</th>
                            <th>Date Range</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        @foreach ($categories as $category)
                            <tr>
                                <td>{{ $loop->index + 1 }}</td>
                                <td>
                                    <a href="{{ $category->image }}" data-lightbox="{{ $category->name }}"
                                        data-title="{{ $category->name }}">
                                        <img src="{{ $category->image }}" alt="{{ $category->name }}"
                                            class="d-block rounded" height="50" width="50" />
                                    </a>
                                </td>
                                <td>
                                    {{ $category->name }}
                                </td>
                                <td class="text-center mx-auto">
                                    {{ $category->products->count() }}
                                </td>
                                <td>
                                    @if ($category->status == 'running')
                                        <span class="badge bg-label-success me-1">{{ $category->status }}</span>
                                    @else
                                        <span class="badge bg-label-danger me-1">{{ $category->status }}</span>
                                    @endif
                                </td>
                                <td>
                                    {{ $category->start_date }}
                                    <span class="me-1">-</span>
                                    {{ $category->end_date }}

                                </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example" data-url="{{route('category.delete',$category->id)}}">
                                        <a class="btn btn-outline-success btn-sm categoryViewBtn" data-id="{{$category->id}}" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#viewCategory">
                                            <i class="bx bxs-show"></i>
                                        </a>
                                        <a class="btn btn-outline-info btn-sm categoryEditBtn" data-id="{{$category->id}}" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#updateCategory"><i
                                                class="bx bx-edit-alt"></i></a>
                                        <a class="btn btn-outline-danger btn-sm itemDeleteBtn"  href="javascript:void(0);">
                                            <i class="bx bx-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    @include('category.view')
    @include('category.create')
    @include('category.edit')
@endsection

{{-- scripts --}}
@push('scripts')

@endpush
