<div class="modal fade" id="updateCategory" tabindex="-1" style="display: none;" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel1">
                    Update Category
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="{{ route('category.update') }}" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <input type="hidden" name="id" id="category_id">
                    <div class="row g-2">
                        <div class="col mb-3">
                            <label for="updateCategoryName" class="form-label required">Name</label>
                            <input type="text" required id="updateCategoryName" name="name" class="form-control"
                                placeholder="Enter Category Name">
                        </div>
                        <div class="col mb-3">
                            <label for="image" class="form-label optional">Image</label>
                            <input type="file" id="image" name="image" class="form-control"
                                placeholder="Upload Category Image">
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-3">
                            <label for="updateCategoryStartDate" class="form-label required">Start Date</label>
                            <input type="date" required id="updateCategoryStartDate" name="start_date" class="form-control category_start_date"
                                placeholder="Enter Start Date">
                        </div>
                        <div class="col mb-3">
                            <label for="updateCategoryEndDate" class="form-label required">End Date</label>
                            <input type="date" required id="updateCategoryEndDate" name="end_date" class="form-control category_end_date"
                                placeholder="Enter End Date">
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col mb-3">
                            <label for="updateCategoryStatus" class="form-label required">Status</label>
                            <select id="updateCategoryStatus" class="select2 form-select" name="status">
                                <option value="scheduled">Scheduled</option>
                                <option value="running">Running</option>
                            </select>
                        </div>
                        <div class="col mb-3">
                            <label for="updateCategoryType" class="form-label optional">Type</label>
                            <select id="updateCategoryType" class="select2 form-select" name="type">
                                <option value="gavel_it">Gavel It</option>
                                <option value="gaveled">Gaveled</option>
                            </select>
                        </div>
                    </div>
                    <div class="col mb-3">
                        <label for="updateCategoryDescription" class="form-label optional">description</label>
                        <textarea id="updateCategoryDescription" class="form-control" rows="4" name="description" placeholder="Enter Category Description"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
