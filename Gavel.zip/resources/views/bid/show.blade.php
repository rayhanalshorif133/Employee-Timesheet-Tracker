@extends('layouts.app')

{{-- styles --}}
@push('styles')
    <style>
    </style>
@endpush

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">

        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Bids /</span> Bid List
        </h4>

        <div class="card my-3">
            <div class="card-body">
                <h5 class="mt-3">Bids List</h5>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5 class="text-bolder">Product Name: <span>
                            @if (count($bids) > 0)
                                {{ $bids[0]->product->name }}
                            @endif
                        </span></h5>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User Name/Phone</th>
                            <th>Bid Amount</th>
                            <th>Date & Time</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        @foreach ($bids as $bid)
                            <tr>
                                <td>{{ $loop->index + 1 }}</td>
                                <td>
                                    <a href="{{ route('user.edit', $bid->user->id) }}">
                                        {{ $bid->user->name ? $bid->user->username : $bid->user->phone }}
                                    </a>
                                </td>
                                <td>{{ $bid->amount }}</td>
                                <td>
                                    @php
                                        $date_time = \Carbon\Carbon::parse($bid->date_time)->format('d-m-Y h:i A');
                                    @endphp
                                    {{$date_time}}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

{{-- scripts --}}
@push('scripts')
@endpush
