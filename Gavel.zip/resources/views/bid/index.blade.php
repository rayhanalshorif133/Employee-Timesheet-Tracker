@extends('layouts.app')

{{-- styles --}}
@push('styles')
    <style>
    </style>
@endpush

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">

        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Bids /</span> Bid List
        </h4>

        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5>Bids List</h5>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Product Name</th>
                            <th>Starting Bid Amount</th>
                            <th>Current Bid Amount</th>
                            <th>Increment Amount</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        @foreach ($bids as $bid)
                            <tr>
                                <td>{{ $loop->index + 1 }}</td>
                                <td>
                                    <a href="{{ route('product.show', $bid->product->id) }}">
                                        {{ $bid->product->name ? $bid->product->name : $bid->product->reference_number }}
                                    </a>
                                </td>
                                <td>{{ $bid->product->starting_bid }}</td>
                                <td>{{ $bid->product->current_bid }}</td>
                                <td>{{ $bid->product->increment }}</td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a class="btn btn-outline-info btn-sm"
                                            href="{{route('bid.show',$bid->product->id)}}">
                                            <i class="bx bxs-show"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

{{-- scripts --}}
@push('scripts')
@endpush
