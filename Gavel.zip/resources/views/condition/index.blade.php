@extends('layouts.app')


@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        

        <h4 class="fw-bold py-3 mb-4">
            <span class="text-muted fw-light">Conditions /</span> Conditions List
        </h4>

        <!-- Hoverable Table rows -->
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between">
                    <h5>Conditions List</h5>
                    <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#createNewCondition">Add New</button>
                </div>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th class="text-center">Name</th>
                            <th class="text-center">Added By</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        @foreach ($conditions as $condition)
                            <tr class="text-center">
                                <td>{{ $loop->index + 1 }}</td>
                                <td class="name w-25">{{ $condition->name }}</td>
                                <td class="nameInput d-none">
                                    <input type="text" class="form-control" id="name" value="{{ $condition->name }}" placeholder="Enter Name">
                                </td>
                                <td><span class="badge bg-label-primary addedByName">{{  $condition->addedBy->username }}</span></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example" data-url="{{route('condition.delete',$condition->id)}}">
                                        <a class="btn btn-outline-info btn-sm itemEditBtn" data-id="{{$condition->id}}" href="javascript:void(0);" data-url="{{route('condition.update')}}">
                                            <i class="bx bx-edit-alt"></i>
                                        </a>
                                        <a class="btn btn-outline-danger btn-sm itemDeleteBtn"  href="javascript:void(0);">
                                            <i class="bx bx-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    @include('condition.create')
@endsection

{{-- scripts --}}
@push('scripts')

@endpush
