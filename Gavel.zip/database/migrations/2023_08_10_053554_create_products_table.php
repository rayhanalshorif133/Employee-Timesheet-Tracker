<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained('categories')->onUpdate('cascade')->onDelete('cascade');
            $table->string('reference_number')->unique();
            $table->string('name')->nullable();
            $table->json('images');
            $table->string('condition_id')->constrained('conditions')->onUpdate('cascade')->onDelete('cascade');
            $table->string('scope_of_delivery_id')->constrained('scope_of_deliveries')->onUpdate('cascade')->onDelete('cascade');
            $table->string('year_of_production')->nullable()->default('Unknown');
            $table->float('case_diameter', 8, 2)->nullable();
            $table->float('lug_width', 8, 2)->nullable();
            $table->string('movement_id')->constrained('movements')->onUpdate('cascade')->onDelete('cascade');
            $table->string('model')->nullable();
            $table->string('brand')->nullable();
            $table->integer('starting_bid')->nullable();
            $table->integer('current_bid')->nullable();
            $table->integer('increment')->default(1000)->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->string('status')->enum('active', 'inactive')->default('active');
            $table->string('type')->enum('old', 'new')->default('new');
            $table->string('verified_status')->enum('pending','accepted', 'rejected')->default('pending');
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
