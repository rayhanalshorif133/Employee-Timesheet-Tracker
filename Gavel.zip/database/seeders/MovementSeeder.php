<?php

namespace Database\Seeders;

use App\Models\Movement;
use Illuminate\Database\Seeder;

class MovementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */

    
    public function __construct()
     {
         $this->run();
     }

    
    public function run()
    {
        Movement::create([
            'name' => 'Automatic',
            'added_by' => 1,
        ]);

        Movement::create([
            'name' => 'Manual winding',
            'added_by' => 1,
        ]);

        Movement::create([
            'name' => 'Quartz',
            'added_by' => 1,
        ]);
    }
}
