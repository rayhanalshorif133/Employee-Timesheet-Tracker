<?php

namespace Database\Seeders;

use App\Models\Condition;
use Illuminate\Database\Seeder;

class ConditionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */

     public function __construct()
     {
         $this->run();
     }

    public function run()
    {
        Condition::create([
            'name' => 'Unworn',
            'added_by' => 1,
        ]);

        Condition::create([
            'name' => 'Very Good',
            'added_by' => 1,
        ]);

        Condition::create([
            'name' => 'Good',
            'added_by' => 1,
        ]);

        Condition::create([
            'name' => 'Fair',
            'added_by' => 1,
        ]);

        Condition::create([
            'name' => 'Poor',
            'added_by' => 1,
        ]);

        Condition::create([
            'name' => 'Incomplete',
            'added_by' => 1,
        ]);
    }
}
