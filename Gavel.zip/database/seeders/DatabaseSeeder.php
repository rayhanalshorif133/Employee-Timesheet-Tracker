<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */

    // public function __construct()
    // {
    //     $this->run();
    // }

    public function run()
    {
        new UserSeeder();
        new CategorySeeder();
        new MovementSeeder();
        new ConditionSeeder();
        new ScopeOfDeliverySeeder();
    }
}
