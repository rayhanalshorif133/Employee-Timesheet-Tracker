<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function __construct()
    {
        $this->run();
    }


    public function run()
    {
        Category::create([
            'name' => 'Luxury Watches',
            'image' => '/images/category/luxury_watches.png',
            'status' => 'scheduled',
            'type' => 'gavel_it',
            'start_date' => '2023-08-11',
            'end_date' => '2023-08-15'
        ]);

        Category::create([
            'name' => 'Exotic Cars',
            'image' => '/images/category/exotic_cars.jpg',
            'status' => 'scheduled',
            'type' => 'gavel_it',
            'start_date' => '2023-08-16',
            'end_date' => '2023-08-20'
        ]);
    }
}
