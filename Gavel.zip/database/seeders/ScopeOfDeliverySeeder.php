<?php

namespace Database\Seeders;

use App\Models\ScopeOfDelivery;
use Illuminate\Database\Seeder;

class ScopeOfDeliverySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     * 
     */

     public function __construct()
     {
         $this->run();
     }
    

    public function run()
    {
        ScopeOfDelivery::create([
            'name' => 'Watch only',
            'added_by' => 1,
        ]);

        ScopeOfDelivery::create([
            'name' => 'Watch with original box',
            'added_by' => 1,
        ]);

        ScopeOfDelivery::create([
            'name' => 'Watch with original papers',
            'added_by' => 1,
        ]);

        ScopeOfDelivery::create([
            'name' => 'Watch with original box and original papers',
            'added_by' => 1,
        ]);
    }
}
